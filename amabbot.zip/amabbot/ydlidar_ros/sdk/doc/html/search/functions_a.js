var searchData=
[
  ['read',['read',['../classserial_1_1_serial.html#a01fc2e3d77cb7d70069de87eca1400e9',1,'serial::Serial::read(uint8_t *buffer, size_t size)'],['../classserial_1_1_serial.html#a3ecd4645c76548ba079eab6f2f46adfb',1,'serial::Serial::read(std::vector&lt; uint8_t &gt; &amp;buffer, size_t size=1)'],['../classserial_1_1_serial.html#ad6c6637fdf8edd85c3a6a63d98fc18f7',1,'serial::Serial::read(std::string &amp;buffer, size_t size=1)'],['../classserial_1_1_serial.html#aa52fbf7d23fb761a46e2400829d2b77a',1,'serial::Serial::read(size_t size=1)']]],
  ['readdata',['readData',['../classserial_1_1_serial.html#a23af62642b1739cf31fb1c8a272074a1',1,'serial::Serial']]],
  ['readline',['readline',['../classserial_1_1_serial.html#a010b18ec545dfe1a7bb1c95be4bdaa54',1,'serial::Serial::readline(std::string &amp;buffer, size_t size=65536, std::string eol=&quot;\n&quot;)'],['../classserial_1_1_serial.html#a04177f637cc02f92ec0492d377528b2a',1,'serial::Serial::readline(size_t size=65536, std::string eol=&quot;\n&quot;)']]],
  ['readlines',['readlines',['../classserial_1_1_serial.html#a2ff222081c30ee4343498c6cc5c14b10',1,'serial::Serial']]],
  ['reset',['reset',['../classydlidar_1_1_y_dlidar_driver.html#a3dd4086c5685163f7c7487ea0f5af08c',1,'ydlidar::YDlidarDriver']]]
];
